﻿namespace moveablepicturebox
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.left = new System.Windows.Forms.Button();
            this.Top = new System.Windows.Forms.Button();
            this.down = new System.Windows.Forms.Button();
            this.Right = new System.Windows.Forms.Button();
            this.moveablePictureBox1 = new moveablepicturebox.MoveablePictureBox(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.moveablePictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // left
            // 
            this.left.Location = new System.Drawing.Point(313, 415);
            this.left.Name = "left";
            this.left.Size = new System.Drawing.Size(75, 23);
            this.left.TabIndex = 0;
            this.left.Text = "Left";
            this.left.UseVisualStyleBackColor = true;
            this.left.Click += new System.EventHandler(this.left_Click);
            // 
            // Top
            // 
            this.Top.Location = new System.Drawing.Point(419, 382);
            this.Top.Name = "Top";
            this.Top.Size = new System.Drawing.Size(75, 23);
            this.Top.TabIndex = 1;
            this.Top.Text = "Top";
            this.Top.UseVisualStyleBackColor = true;
            this.Top.Click += new System.EventHandler(this.Top_Click);
            // 
            // down
            // 
            this.down.Location = new System.Drawing.Point(419, 415);
            this.down.Name = "down";
            this.down.Size = new System.Drawing.Size(75, 23);
            this.down.TabIndex = 2;
            this.down.Text = "Down";
            this.down.UseVisualStyleBackColor = true;
            this.down.Click += new System.EventHandler(this.down_Click);
            // 
            // Right
            // 
            this.Right.Location = new System.Drawing.Point(511, 415);
            this.Right.Name = "Right";
            this.Right.Size = new System.Drawing.Size(75, 23);
            this.Right.TabIndex = 3;
            this.Right.Text = "Right";
            this.Right.UseVisualStyleBackColor = true;
            this.Right.Click += new System.EventHandler(this.Right_Click);
            // 
            // moveablePictureBox1
            // 
            this.moveablePictureBox1.Image = global::moveablepicturebox.Properties.Resources.finallyopen;
            this.moveablePictureBox1.Location = new System.Drawing.Point(535, 43);
            this.moveablePictureBox1.Name = "moveablePictureBox1";
            this.moveablePictureBox1.Size = new System.Drawing.Size(100, 139);
            this.moveablePictureBox1.TabIndex = 4;
            this.moveablePictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.moveablePictureBox1);
            this.Controls.Add(this.Right);
            this.Controls.Add(this.down);
            this.Controls.Add(this.Top);
            this.Controls.Add(this.left);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.moveablePictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button left;
        private System.Windows.Forms.Button Top;
        private System.Windows.Forms.Button down;
        private System.Windows.Forms.Button Right;
        private MoveablePictureBox moveablePictureBox1;
    }
}

