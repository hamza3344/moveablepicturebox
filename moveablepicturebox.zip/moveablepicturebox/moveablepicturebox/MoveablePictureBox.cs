﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace moveablepicturebox
{
    public class MoveablePictureBox : PictureBox
    {
        public MoveablePictureBox(IContainer c) {
            c.Add(this);
        }
        Point point;
        protected override void OnMouseDown(MouseEventArgs e)
        {
            point = e.Location;
            base.OnMouseDown(e);
        }
        protected override void OnMouseMove(MouseEventArgs e)
        {
            if(e.Button== MouseButtons.Left)
            {
                this.Left += e.X-point.X;
                this.Top+= e.Y-point.Y;
            }
            base.OnMouseMove(e);
        }
        public Point getlocation()
        {
            return this.Location;
        }
        public void moveleft(int x=50)
        {
            this.Left-= x;
        }
        public void moveright(int x = 50)
        {
            this.Left += x;
        }
        public void movetop(int x = 50)
        {
            this.Top -= x;
        }
        public void movedown(int x = 50)
        {
            this.Top += x;
        }
    }
}
